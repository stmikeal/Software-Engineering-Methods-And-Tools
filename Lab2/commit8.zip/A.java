public class A extends null {

    int[] ii();

    void aa();
}
