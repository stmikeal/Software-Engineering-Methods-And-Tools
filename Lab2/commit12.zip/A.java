public class A extends null {

    int[] ii();

    void aa();

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public byte oo() {
        return 2;
    }
}
