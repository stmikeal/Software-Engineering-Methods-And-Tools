public class H extends F {

    private long h = 1234;

    private int f = 1;

    public double ee() {
        return 0.000001;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public float ff() {
        return 0;
    }

    public void aa() {
        return;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public int cc() {
        return 39;
    }
}
