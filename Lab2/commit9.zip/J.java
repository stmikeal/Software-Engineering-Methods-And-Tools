public class J extends null {

    private long a = 4321;

    private String f = "test";

    public int cc() {
        return 39;
    }

    public int af() {
        return -1;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public long dd() {
        return 99999;
    }
}
