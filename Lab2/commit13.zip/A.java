public class A extends null {

    int[] ii();

    void aa();

    public int af() {
        return -1;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public int cc() {
        return 13;
    }
}
