public class H extends F {

    private long h = 1234;

    private int f = 1;

    public double ee() {
        return 0.000001;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public void aa() {
        System.out.println("void aa");
    }

    public float ff() {
        return 0;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public long dd() {
        return 33;
    }

    public double ad() {
        return 12.12;
    }

    public int cc() {
        return 13;
    }
}
