public class H extends F {

    private long h = 1234;

    private int f = 1;

    public double ee() {
        return 0.000001;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public float ff() {
        return 0;
    }

    public void aa() {
        return;
    }
}
