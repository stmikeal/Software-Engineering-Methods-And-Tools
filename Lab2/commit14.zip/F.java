public class F extends null {

    private String j = "test";

    private double e = 100.500;

    public Object pp() {
        return this;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public Object rr() {
        return null;
    }

    public double ee() {
        return 100.500;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public int ae() {
        return 9;
    }

    public int af() {
        return -1;
    }

    public long ac() {
        return 222;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }
}
