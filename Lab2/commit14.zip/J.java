public class J extends null {

    private long a = 4321;

    private String f = "test";

    public int cc() {
        return 39;
    }

    public int af() {
        return -1;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public Object pp() {
        return this;
    }

    public long dd() {
        return 99999;
    }

    public Object gg() {
        return new java.util.Random();
    }

    public byte oo() {
        return 4;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public String kk() {
        return "No";
    }
}
