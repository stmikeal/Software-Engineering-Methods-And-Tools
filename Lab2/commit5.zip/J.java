public class J {

    private long a = 4321;

    private String f = "test";

    public int cc() {
        return 39;
    }

    public int af() {
        return -1;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }
}
