public class F {

    private String j = "test";

    private double e = 100.500;

    public Object pp() {
        return this;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public Object rr() {
        return null;
    }
}
