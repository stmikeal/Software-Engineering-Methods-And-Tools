public interface A {

    int[] ii();

    void aa();
}
